import numpy as np
import matplotlib.pylab as plt

x = np.linspace(-5, 5)
y = x

plt.plot(x, y)
plt.show()